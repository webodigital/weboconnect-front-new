.header {
    background-color: <?php echo $header_background_color; ?>;
    color: <?php echo $header_text_color; ?>;
}
.header a {
    color: <?php echo $header_text_color; ?>;
    border: 1px solid <?php echo $header_text_color; ?>;
}
.footer {
    background-color: <?php echo $footer_background_color; ?>;
    color: <?php echo $footer_text_color; ?>;
}
.card-header {
    background-color: <?php echo $header_background_color; ?>;
    color: <?php echo $header_text_color; ?>;
}
