<div class="col-auto text-center animate__animated animate__bounceInDown">
  <div class="google_ratings_card">
    <a href="https://www.goodfirms.co/company/weboconnect-technlogies-pvt-ltd" target="_blank">
      <img style="" class="w-100" height="80" src="<?=base_url()?>assets/images/weboconnect_assets/goodfirm.webp" alt="goodfirm" title="goodfirm">
      <div class="d-flex flex-wrap">
        <span>Excellent</span>
        <span>.</span>
        <span>5/5</span>
        <span>.</span>
        <span>38 REVIEWS</span>
      </div>
    </a>
  </div>
</div>

<div class="col-auto text-center animate__animated animate__bounceInDown">
  <div class="google_ratings_card">
    <a href="https://g.co/kgs/LRSpRA5" target="_blank">
      <img style="" class="w-100" height="80" src="<?=base_url()?>assets/images/weboconnect_assets/google_ratings.webp" alt="google ratings" title="google ratings">
      <div class="d-flex flex-wrap">
        <span>4.7/5</span>
        <span>.</span>
        <span>26 Google reviews</span>
      </div>
    </a>
  </div>
</div>

<div class="col-auto text-center animate__animated animate__bounceInDown">
  <div class="google_ratings_card">
    <a href="https://clutch.co/profile/weboconnect-technologies?utm_source=widget&amp;utm_medium=1&amp;utm_campaign=widget&amp;utm_content=num_reviews&amp;utm_term=localhost#reviews" target="_blank">
      <img style="" class="w-100" height="80" src="<?=base_url()?>assets/images/weboconnect_assets/clutch.webp" alt="clutch" title="clutch">
      <div class="d-flex flex-wrap">
        <span>5/5</span>
        <span>12 REVIEWS</span>
      </div>
    </a>
  </div>
</div>

<div class="col-auto text-center animate__animated animate__bounceInDown">
  <div class="google_ratings_card">
    <a href="https://www.trustpilot.com/review/weboconnect.com" target="_blank">
      <img style="" class="w-100" height="80" src="<?=base_url()?>assets/images/weboconnect_assets/trustpilot.webp" alt="trustpilot" title="trustpilot">
      <div class="d-flex flex-wrap">
        <span>4.6/5</span>
        <span>.</span>
        <span>17 Reviews</span>
        <span>.</span>
        <span>Excellent</span>
      </div>
    </a>
  </div>
</div>

<div class="col-auto text-center animate__animated animate__bounceInDown" data-wow-duration="2s" data-wow-delay="5s">
  <div class="google_ratings_card">
    <a href="https://www.designrush.com/agency/profile/weboconnect-technologies-pvt-ltd" target="_blank">
      <img style="" class="w-100" height="80" src="<?=base_url()?>assets/images/weboconnect_assets/design_rush.webp" alt="trustpilot" title="trustpilot">
      <div class="d-flex flex-wrap">
        <span>4.8</span>
        <span>.</span>
        <span>(19 Reviews)</span>
      </div>
    </a>
  </div>
</div>