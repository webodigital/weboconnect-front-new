

    <div class="owl-carousel owl-theme trusted_top_companies_slider">
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_1.webp" alt="canavas">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_2.webp" alt="digital Business networks alliance">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_3.webp" alt="anyshyft">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_4.webp" alt="india on track">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_4.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_5.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_6.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_7.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_8.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_9.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_10.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_11.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_12.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_13.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_14.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_15.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_16.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_17.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_18.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_19.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_20.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_21.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_22.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_23.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_24.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_25.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_26.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_27.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_28.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_29.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_30.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_31.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_32.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_33.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_34.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_35.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_36.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_37.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_38.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_39.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_40.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_41.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_42.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_43.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_44.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_45.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_46.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_47.webp" alt="allmatters">
            </div>
        </div>
        <div class="item">
            <div class="">
                <img src="<?= base_url() ?>assets/images/trusted_companies/logo_48.webp" alt="allmatters">
            </div>
        </div>

    </div>
